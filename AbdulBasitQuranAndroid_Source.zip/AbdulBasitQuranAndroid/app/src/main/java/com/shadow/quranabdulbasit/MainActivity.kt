package com.shadow.quranabdulbasit

import android.os.Bundle
import android.media.AudioAttributes
import android.media.AudioManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private val Ink = Color(0xFF080D0C)
private val Panel = Color(0xFF121B18)
private val Gold = Color(0xFFD7B66D)
private val Cream = Color(0xFFF3EBD8)
private val Muted = Color(0xFF9DAAA2)

data class Surah(val number: Int, val name: String, val verses: Int, val place: String)
data class Ayah(val number: Int, val text: String)

private val surahs = listOf(
    Surah(1,"الفاتحة",7,"مكية"), Surah(2,"البقرة",286,"مدنية"), Surah(3,"آل عمران",200,"مدنية"),
    Surah(4,"النساء",176,"مدنية"), Surah(5,"المائدة",120,"مدنية"), Surah(6,"الأنعام",165,"مكية"),
    Surah(7,"الأعراف",206,"مكية"), Surah(8,"الأنفال",75,"مدنية"), Surah(9,"التوبة",129,"مدنية"),
    Surah(10,"يونس",109,"مكية"), Surah(11,"هود",123,"مكية"), Surah(12,"يوسف",111,"مكية"),
    Surah(13,"الرعد",43,"مدنية"), Surah(14,"إبراهيم",52,"مكية"), Surah(15,"الحجر",99,"مكية"),
    Surah(16,"النحل",128,"مكية"), Surah(17,"الإسراء",111,"مكية"), Surah(18,"الكهف",110,"مكية"),
    Surah(19,"مريم",98,"مكية"), Surah(20,"طه",135,"مكية"), Surah(21,"الأنبياء",112,"مكية"),
    Surah(22,"الحج",78,"مدنية"), Surah(23,"المؤمنون",118,"مكية"), Surah(24,"النور",64,"مدنية"),
    Surah(25,"الفرقان",77,"مكية"), Surah(26,"الشعراء",227,"مكية"), Surah(27,"النمل",93,"مكية"),
    Surah(28,"القصص",88,"مكية"), Surah(29,"العنكبوت",69,"مكية"), Surah(30,"الروم",60,"مكية"),
    Surah(31,"لقمان",34,"مكية"), Surah(32,"السجدة",30,"مكية"), Surah(33,"الأحزاب",73,"مدنية"),
    Surah(34,"سبأ",54,"مكية"), Surah(35,"فاطر",45,"مكية"), Surah(36,"يس",83,"مكية"),
    Surah(37,"الصافات",182,"مكية"), Surah(38,"ص",88,"مكية"), Surah(39,"الزمر",75,"مكية"),
    Surah(40,"غافر",85,"مكية"), Surah(41,"فصلت",54,"مكية"), Surah(42,"الشورى",53,"مكية"),
    Surah(43,"الزخرف",89,"مكية"), Surah(44,"الدخان",59,"مكية"), Surah(45,"الجاثية",37,"مكية"),
    Surah(46,"الأحقاف",35,"مكية"), Surah(47,"محمد",38,"مدنية"), Surah(48,"الفتح",29,"مدنية"),
    Surah(49,"الحجرات",18,"مدنية"), Surah(50,"ق",45,"مكية"), Surah(51,"الذاريات",60,"مكية"),
    Surah(52,"الطور",49,"مكية"), Surah(53,"النجم",62,"مكية"), Surah(54,"القمر",55,"مكية"),
    Surah(55,"الرحمن",78,"مدنية"), Surah(56,"الواقعة",96,"مكية"), Surah(57,"الحديد",29,"مدنية"),
    Surah(58,"المجادلة",22,"مدنية"), Surah(59,"الحشر",24,"مدنية"), Surah(60,"الممتحنة",13,"مدنية"),
    Surah(61,"الصف",14,"مدنية"), Surah(62,"الجمعة",11,"مدنية"), Surah(63,"المنافقون",11,"مدنية"),
    Surah(64,"التغابن",18,"مدنية"), Surah(65,"الطلاق",12,"مدنية"), Surah(66,"التحريم",12,"مدنية"),
    Surah(67,"الملك",30,"مكية"), Surah(68,"القلم",52,"مكية"), Surah(69,"الحاقة",52,"مكية"),
    Surah(70,"المعارج",44,"مكية"), Surah(71,"نوح",28,"مكية"), Surah(72,"الجن",28,"مكية"),
    Surah(73,"المزمل",20,"مكية"), Surah(74,"المدثر",56,"مكية"), Surah(75,"القيامة",40,"مكية"),
    Surah(76,"الإنسان",31,"مدنية"), Surah(77,"المرسلات",50,"مكية"), Surah(78,"النبأ",40,"مكية"),
    Surah(79,"النازعات",46,"مكية"), Surah(80,"عبس",42,"مكية"), Surah(81,"التكوير",29,"مكية"),
    Surah(82,"الانفطار",19,"مكية"), Surah(83,"المطففين",36,"مكية"), Surah(84,"الانشقاق",25,"مكية"),
    Surah(85,"البروج",22,"مكية"), Surah(86,"الطارق",17,"مكية"), Surah(87,"الأعلى",19,"مكية"),
    Surah(88,"الغاشية",26,"مكية"), Surah(89,"الفجر",30,"مكية"), Surah(90,"البلد",20,"مكية"),
    Surah(91,"الشمس",15,"مكية"), Surah(92,"الليل",21,"مكية"), Surah(93,"الضحى",11,"مكية"),
    Surah(94,"الشرح",8,"مكية"), Surah(95,"التين",8,"مكية"), Surah(96,"العلق",19,"مكية"),
    Surah(97,"القدر",5,"مكية"), Surah(98,"البينة",8,"مدنية"), Surah(99,"الزلزلة",8,"مدنية"),
    Surah(100,"العاديات",11,"مكية"), Surah(101,"القارعة",11,"مكية"), Surah(102,"التكاثر",8,"مكية"),
    Surah(103,"العصر",3,"مكية"), Surah(104,"الهمزة",9,"مكية"), Surah(105,"الفيل",5,"مكية"),
    Surah(106,"قريش",4,"مكية"), Surah(107,"الماعون",7,"مكية"), Surah(108,"الكوثر",3,"مكية"),
    Surah(109,"الكافرون",6,"مكية"), Surah(110,"النصر",3,"مدنية"), Surah(111,"المسد",5,"مكية"),
    Surah(112,"الإخلاص",4,"مكية"), Surah(113,"الفلق",5,"مكية"), Surah(114,"الناس",6,"مكية")
)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private val job = SupervisorJob()
    private val scope by lazy { CoroutineScope(Dispatchers.Main + job) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        player.setAudioAttributes(
            androidx.media3.common.AudioAttributes.Builder()
                .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
        )
        setContent { QuranApp(this, player, scope) }
    }

    override fun onDestroy() {
        player.release()
        job.cancel()
        super.onDestroy()
    }
}

@Composable
fun QuranApp(context: Context, player: ExoPlayer, scope: CoroutineScope) {
    var selected by remember { mutableStateOf(surahs[54]) }
    var query by remember { mutableStateOf("") }
    var isPlaying by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("اختر سورة وابدأ الاستماع") }
    var ayahs by remember { mutableStateOf<List<Ayah>>(emptyList()) }
    var showTimer by remember { mutableStateOf(false) }
    var timerMinutes by remember { mutableIntStateOf(15) }
    var timerJob by remember { mutableStateOf<Job?>(null) }
    var downloading by remember { mutableStateOf(false) }
    var savedSurahs by remember { mutableStateOf(setOf<Int>()) }
    var tab by remember { mutableStateOf(0) }
    val prefs = remember { context.getSharedPreferences("favorites", Context.MODE_PRIVATE) }
    LaunchedEffect(Unit) {
        savedSurahs = prefs.getStringSet("surahs", emptySet())?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        })
        loadAyahs(selected.number) { ayahs = it }
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, onPrimary = Ink, background = Ink, surface = Panel,
        onSurface = Cream, secondary = Gold
    )) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17241E), Ink, Color(0xFF090A0C))))) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(24.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("عبد الباسط عبد الصمد", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("رَوَائِعُ التِّلَاوَات", color = Muted, fontSize = 13.sp)
                    }
                    Box(Modifier.size(48.dp).background(Color(0xFF26362D), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.MusicNote, null, tint = Gold, modifier = Modifier.size(27.dp))
                    }
                }
                Spacer(Modifier.height(18.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF18231E)), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("الآن تستمع إلى", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(5.dp))
                        Text("سورة ${selected.name}", color = Cream, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("بصوت القارئ الشيخ عبد الباسط عبد الصمد", color = Gold, fontSize = 13.sp)
                        Spacer(Modifier.height(16.dp))
                        Box(Modifier.fillMaxWidth().height(4.dp).background(Color(0xFF35443A), RoundedCornerShape(8.dp))) {
                            Box(Modifier.fillMaxWidth(if (isPlaying) 0.42f else 0.08f).fillMaxHeight().background(Gold, RoundedCornerShape(8.dp)))
                        }
                        Spacer(Modifier.height(15.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { playSurah(context, player, selected, scope) { status = it } }) {
                                Icon(Icons.Default.Replay, null, tint = Gold)
                            }
                            Spacer(Modifier.width(16.dp))
                            IconButton(
                                onClick = {
                                    if (player.isPlaying) player.pause()
                                    else if (player.mediaItemCount > 0) player.play()
                                    else playSurah(context, player, selected, scope) { status = it }
                                },
                                modifier = Modifier.size(60.dp).background(Gold, CircleShape)
                            ) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Ink, modifier = Modifier.size(34.dp)) }
                            Spacer(Modifier.width(16.dp))
                            IconButton(onClick = { showTimer = true }) { Icon(Icons.Default.Bedtime, null, tint = Gold) }
                        }
                        Text(status, color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf("السور", "الآيات", "المفضلة").forEachIndexed { i, label ->
                        FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = Ink))
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = {
                        val newSet = if (selected.number in savedSurahs) savedSurahs - selected.number else savedSurahs + selected.number
                        savedSurahs = newSet
                        prefs.edit().putStringSet("surahs", newSet.map { it.toString() }.toSet()).apply()
                    }) { Icon(if (selected.number in savedSurahs) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Gold) }
                }
                if (tab == 0) {
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Search, null, tint = Gold)
                        Spacer(Modifier.width(8.dp))
                        BasicTextField(value = query, onValueChange = { query = it }, singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Cream, fontSize = 15.sp),
                            decorationBox = { inner -> if (query.isEmpty()) Text("ابحث عن سورة...", color = Muted); inner() },
                            modifier = Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                        items(surahs.filter { it.name.contains(query.trim()) || it.number.toString() == query.trim() }) { s ->
                            SurahRow(s, selected.number == s.number, s.number in savedSurahs) {
                                selected = s
                                tab = 1
                                loadAyahs(s.number) { ayahs = it }
                                status = "تم اختيار سورة ${s.name}"
                            }
                        }
                    }
                } else if (tab == 1) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("آيات سورة ${selected.name}", color = Gold, fontWeight = FontWeight.Bold)
                        TextButton(onClick = {
                            downloading = true
                            scope.launch {
                                val ok = downloadSurah(context, selected)
                                downloading = false
                                status = if (ok) "تم تحميل سورة ${selected.name} للاستماع دون إنترنت" else "تعذّر التحميل؛ تحقق من الإنترنت"
                                Toast.makeText(context, status, Toast.LENGTH_LONG).show()
                            }
                        }, enabled = !downloading) {
                            if (downloading) CircularProgressIndicator(Modifier.size(16.dp), color = Gold, strokeWidth = 2.dp)
                            else Icon(Icons.Default.Download, null, tint = Gold)
                            Spacer(Modifier.width(4.dp)); Text("تحميل السورة", color = Gold)
                        }
                    }
                    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ayahs) { a ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                                Text("${a.text}  ۞ ${a.number}", color = Cream, fontSize = 19.sp, textAlign = TextAlign.Right,
                                    modifier = Modifier.fillMaxWidth().padding(14.dp))
                            }
                        }
                    }
                } else {
                    val favs = surahs.filter { it.number in savedSurahs }
                    if (favs.isEmpty()) {
                        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Text("اضغط القلب لحفظ السور المفضلة", color = Muted) }
                    } else {
                        LazyColumn { items(favs) { s -> SurahRow(s, selected.number == s.number, true) { selected = s; tab = 1; loadAyahs(s.number) { ayahs = it } } } }
                    }
                }
            }
        }
        if (showTimer) {
            AlertDialog(
                onDismissRequest = { showTimer = false },
                title = { Text("مؤقت النوم", color = Gold) },
                text = {
                    Column {
                        Text("إيقاف التلاوة بعد $timerMinutes دقيقة", color = Cream)
                        Slider(value = timerMinutes.toFloat(), onValueChange = { timerMinutes = it.toInt() }, valueRange = 5f..120f, steps = 22)
                        Text("يمكنك إلغاء المؤقت بإعادة فتح هذه النافذة وإيقافه.", color = Muted, fontSize = 12.sp)
                    }
                },
                confirmButton = { TextButton(onClick = {
                    timerJob?.cancel()
                    timerJob = scope.launch {
                        delay(timerMinutes * 60_000L)
                        player.pause()
                        status = "انتهى مؤقت النوم"
                    }
                    showTimer = false
                    status = "سيتم إيقاف التلاوة بعد $timerMinutes دقيقة"
                }) { Text("تشغيل المؤقت", color = Gold) } },
                dismissButton = { TextButton(onClick = { timerJob?.cancel(); timerJob = null; showTimer = false; status = "تم إلغاء مؤقت النوم" }) { Text("إلغاء المؤقت", color = Cream) } },
                containerColor = Panel
            )
        }
    }
}

@Composable
private fun SurahRow(s: Surah, selected: Boolean, favorite: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(if (selected) Color(0xFF26372E) else Panel, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).background(Color(0xFF26362D), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
            Text(s.number.toString(), color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.name, color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text("${s.verses} آية • ${s.place}", color = Muted, fontSize = 11.sp)
        }
        if (favorite) Icon(Icons.Default.Favorite, null, tint = Gold, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Icon(Icons.Default.ChevronLeft, null, tint = Muted)
    }
}

private fun audioUrl(surah: Int, ayah: Int): String {
    return "https://everyayah.com/data/Abdul_Basit_Murattal_64kbps/${surah.toString().padStart(3,'0')}${ayah.toString().padStart(3,'0')}.mp3"
}
private fun localAudio(context: Context, s: Int, a: Int) = File(File(context.filesDir, "audio"), "${s.toString().padStart(3,'0')}${a.toString().padStart(3,'0')}.mp3")

private fun playSurah(context: Context, player: ExoPlayer, surah: Surah, scope: CoroutineScope, message: (String) -> Unit) {
    scope.launch {
        try {
            val items = (1..surah.verses).map { ayah ->
                val local = localAudio(context, surah.number, ayah)
                MediaItem.fromUri(if (local.exists() && local.length() > 0) Uri.fromFile(local) else Uri.parse(audioUrl(surah.number, ayah)))
            }
            player.setMediaItems(items)
            player.prepare()
            player.play()
            message("جاري تشغيل سورة ${surah.name}")
        } catch (e: Exception) { message("تعذّر تشغيل التلاوة؛ تحقق من الاتصال بالإنترنت") }
    }
}

private suspend fun downloadSurah(context: Context, surah: Surah): Boolean = withContext(Dispatchers.IO) {
    try {
        val dir = File(context.filesDir, "audio").apply { mkdirs() }
        for (ayah in 1..surah.verses) {
            val target = File(dir, "${surah.number.toString().padStart(3,'0')}${ayah.toString().padStart(3,'0')}.mp3")
            if (target.exists() && target.length() > 0) continue
            val conn = (URL(audioUrl(surah.number, ayah)).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000; readTimeout = 20000; requestMethod = "GET"
            }
            conn.inputStream.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
            conn.disconnect()
        }
        true
    } catch (_: Exception) { false }
}

private fun loadAyahs(surah: Int, done: (List<Ayah>) -> Unit) {
    CoroutineScope(Dispatchers.IO).launch {
        val result = try {
            val conn = URL("https://api.alquran.cloud/v1/surah/$surah").openConnection() as HttpURLConnection
            conn.connectTimeout = 10000; conn.readTimeout = 10000
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val data = JSONObject(body).getJSONObject("data").getJSONArray("ayahs")
            (0 until data.length()).map { i ->
                val obj = data.getJSONObject(i)
                Ayah(obj.getInt("numberInSurah"), obj.getString("text"))
            }
        } catch (_: Exception) { emptyList() }
        withContext(Dispatchers.Main) { done(result) }
    }
}
